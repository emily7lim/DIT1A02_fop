//student ID: 1936207
//name: Emily Lim Xiang Qin
//class:DIT1A02

var input = require('readline-sync');
var ai = input.question("Enter your annual income: ");
var fs = input.question("Enter your filing status: \na - Single filer\nb - Married Filing Jointly\n> ");
var tax = 0;
var a = a;
var b = b;

if (fs != a || fs != b) {
    console.log("Invaild Filing Status.\nProgram Terminated...");
}

else {
    
    while (fs == a || fs == b) {
    if (fs == a) {
        if (ai <= 6000) {
            tax += parseInt(ai * (10 / 100));
        }
        else if (ai > 6000 && ai<20000) {

            ai -= 6000;
            tax += parseInt(ai * (15 / 100));

            tax += 6000;
        }
        else if (ai>20000) {
            tax +=2700;
            tax += parseInt((ai-20000)*(27/100));
        }
    }
    else {
        if (ai <= 12000) {
            tax += parseInt(ai * (10 / 100));
        }

        else if (ai > 12000 && ai<38000) {
            tax += parseInt((ai-12000)*(15/100));
        }

        else if (ai>38000) {
            tax +=5100;
            tax += parseInt((ai-38000)*(27/100));
        }
    }
}
    console.log("Your tax amount is $" + tax);
}

