//student ID: 1936207
//name: Emily Lim Xiang Qin
//class:DIT1A02

var input = require('readline-sync');

var num = input.questionInt("Enter a number: ");

while (num <= 0) {
    console.log("Number entered must be greater than 0.\nPlease enter again..");
    var num = input.questionInt("Enter a number: ");

}
if (num > 0) {
    if (num % 2 == 0) {
        console.log(num + " is an even number.");
    }
    else
        console.log(num + " is an odd number.");

}

var sum = parseInt(Math.floor(num / 1) + Math.floor(num / 10) + Math.floor(num / 100) + Math.floor(num / 1000));
console.log("The sum is " + sum);


