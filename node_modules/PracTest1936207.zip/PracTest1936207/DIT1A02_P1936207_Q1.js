//student ID: 1936207
//name: Emily Lim Xiang Qin
//class:DIT1A02

var input = require('readline-sync');
var area = 0;
var a = parseFloat(input.question("Enter value for the first parallel side of the trapezium: "));
var b = parseFloat(input.question("Enter value for the second parallel side of the trapezium: "));
var h = parseFloat(input.question("Enter value for the height of the trapezium: "));
area = (((a + b) / 2) * h);
console.log("The area of the trapezium is " + area);

